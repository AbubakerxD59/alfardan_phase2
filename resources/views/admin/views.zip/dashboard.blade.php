@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Tenant')

@section('content')


<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
@include('notification.notify')
  

	<h2 class="table-cap  mb-2">Tenant</h2>
	<div class=" table-responsive tenant-table">
		<table class="table  table-bordered" id="myTable">
			<thead>
				<tr>
					<th>First Name</th>
          <th>Last Name</th>
					<th scope="col"><span>Email</span></th>
					<!-- <th scope="col"><span>Password</span></th> -->
					<!-- <th scope="col"><span>Start Date</span></th> -->
					<th scope="col"><span>Date of Birth</span></th>
					<th scope="col"><span>Phone Number</span></th>
					<th scope="col"><span>Tel. Number</span></th>
					<!-- <th scope="col"><span>Leasing Type</span></th> -->
					<!-- <th scope="col"><Span>Tenant Type</Span></th> -->
					<th scope="col"><span>Property</span></th>
					<th scope="col"><span>Apartment</span></th>
          <th scope="col"><span>Edit</span></th>
          <th scope="col"><span>Remove</span></th>


					<!-- <th scope="col"><span>No. Of Members</span></th> -->
					<!-- <th colspan="2"></th> -->
				</tr>
			</thead>
			<tbody>
				@foreach ($users as $key => $user)
					
					<tr>
						<td><a href="{{ route('admin.user_info',$user->id)}}" >{{$user->first_name}}</a></td>
            <td><a href="{{ route('admin.user_info',$user->id)}}" >{{$user->last_name}}</a></td>
						<td>{{$user->email}}</td>
						<!-- <td>{{$user->password}}</td> -->
						<!-- <td></td> -->
						<td>{{$user->dob}}</td>
						<td>{{$user->mobile}}</td>
						<td>{{$user->telephone}}</td>
						<!-- <td></td> -->
						<!-- <td></td> -->
						<td>{{$user->property}}</td>
						<td>{{$user->apt_number}}</td>
						<!-- <td></td> -->
						<!-- <td class="btn-bg1" id="edit_user" class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser" data-username="{{$user->first_name}}" data-email="{{$user->email}}" data-phone="{{$user->mobile}}" data-apt="{{$user->apt_number}}" data-id="{{$user->id}}" >EDIT </td> -->
						<!-- <td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</a></td> -->
            <td>
              <button class="btn-bg1"  class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser" data-firstname="{{$user->first_name}}" data-lastname="{{$user->last_name}}" data-email="{{$user->email}}" data-phone="{{$user->mobile}}" data-apt="{{$user->apt_number}}" data-userid="{{$user->id}}" data-userimage="{{asset('placeholder.png')}}" style="background: none;border: none;color: #fff;">EDIT</button>
            </td>
            <td>
              <!-- <form method="POST" action="{{ route('admin.delete_user', $user->id) }}"> -->
                <!-- @csrf -->
                <!-- <input name="_method" type="hidden" value="DELETE"> -->
                <button class="fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item"  title='REMOVE' data-userid="{{$user->id}}" style="background: none;border: none;color: #fff;">REMOVE</button>
              <!-- </form> -->
            </td>
					</tr>
				@endforeach

			</tbody>
		</table>
	</div>
</main>
</div>
</div>
<!-- edit Modal model start -->
<div class="modal fade" id="editUser"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog ">
    
    <div class="modal-content  bg-transparent border-0">
      <div class="modal-body">
        <div class="container-fluid px-0">
          <div class="scnd-type-modal-form-wrapper more-extra-width">
            <form method="post" enctype="multipart/form-data">
              {{method_field('patch')}}
              {{csrf_field()}}
              <input type="hidden" name="userid" id="userid" value="">

              <h2 class="form-caption">Edit User</h2>
              <button type="button" class="btn-close-modal float-end" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
              <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-5">
                  <!-- frst row -->
                  <div class="row">
                    <div class="input-field-group ">
                      <label for="username">First Name</label>
                      <input class="w-100" type="text" name="first_name" id="first_name">
                    </div>

                    <div class="input-field-group ">
                      <label for="username">Last Name</label>
                      <input class="w-100" type="text" name="last_name" id="last_name">
                    </div>

                    <div class="input-field-group">
                      <label for="username">Email</label>
                      <input class="w-100" type="email" name="email" id="email">
                    </div>

                    <div class="input-field-group">
                      <label for="username">Phone Number</label>
                      <input class="w-100" type="text" name="mobile" id="mobile">
                    </div>

                    <div class="input-field-group">
                      <label for="username">Start Date</label>
                      <input class="w-100" type="date" name="start_date" id="username">
                    </div>

                    <div class="input-field-group">
                      <label for="username">Leasig Type</label>
                      <input class="w-100" type="text" name="leasing_type" id="username">
                    </div>

                    <div class="input-field-group">
                      <label for="username">Apartment</label>
                      <input class="w-100" type="text" name="apt_number" id="apt">
                    </div>

                  </div>

                </div>
                <div class=" col-xl-8 col-lg-8 ps-xl-0 ps-lg-5 col-md-7">
                  <div class="row">
                    <div class="col-xl-5 col-lg-6">
                      <div class="profile-img-holder mb-3">
                          <figcaption>Images</figcaption>
                          <div id="add-tenant-img-preview" class="image-preview">
                            <label for="add-tenant-img-upload" id="add-tenant-img-label">Choose File</label>
                            <input type="file" name="image" id="add-tenant-img-upload" />
                          </div> 
                      </div>
                    </div>
                  </div>
                 
                 <!-- 2nd row -->

                  <div class="radio-input-group mb-lg-3 mb-md-0">
                    <h2>Tenant</h2>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="tenant" type="radio" id="vip" value="option2">
                      <label class="form-check-label" for="vip">VIP</label>
                    </div>

                     <div class="form-check form-check-inline">
                      <input class="form-check-input" name="tenant" type="radio" id="regular" value="option2">
                      <label class="form-check-label" for="regular">Regular</label>
                    </div>

                     <div class="form-check form-check-inline">
                        <input class="form-check-input" name="tenant" type="radio" id="nontenent" value="option2">
                        <label class="form-check-label" for="nontenent">Non-tenant</label>
                    </div>

                    <h2>Property</h2>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property1" value="option2">
                      <label class="form-check-label" for="Property1">Property1</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property2" value="option2">
                      <label class="form-check-label" for="Property2">Property2</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property3" value="option2">
                      <label class="form-check-label" for="Property3">Property3</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property4" value="option2">
                      <label class="form-check-label" for="Property4">Property4</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property5" value="option2">
                      <label class="form-check-label" for="Property5">Property5</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property6" value="option2">
                      <label class="form-check-label" for="Property6">Property6</label>
                    </div>

                    <div class="form-check form-check-inline">
                      <input class="form-check-input" name="property" type="radio" id="Property7" value="option2">
                      <label class="form-check-label" for="Property7">Property7</label>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-xl-5">
                      <div class="input-field-group ">
                        <label for="username">N0. of Users</label>
                        <input type="text" name="username" id="username">
                      </div>
                    </div>

                    <div class="col-xl-7 mt-auto">
                      <div class="btn-holder">
                        <a href="#">Publish</a>
                        <a href="#">Draft</a>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
              
              <!-- sixth row-->
              
              
            </form>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>
</div>
<!-- edit Modal model end -->
<!-- delete modal start -->
<div class="modal remove-item" id="remove-item" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-transparent border-0">
      <form method="POST" action="{{ route('admin.delete_user','user') }}">
      {{method_field('delete')}}
      {{csrf_field()}}
      <div class="modal-body">
        <div class="remove-content-wrapper">
          <p>Are you sure you want to delete?</p>
          <input type="hidden" name="user_id" id="user_id" value="">

          <div class="delete-btn-wrapper">
            <a href="#" type="button" class="btn-close-modal" data-bs-dismiss="modal" aria-label="Close">cancel</a>
            <!-- <a href="#">delete</a> -->
            <button type="Submit" 
            style="color: #fff;
            font-size: 18px;
            max-width: 133px;
            height: 37px;
            padding: 7px 32px;
            border: 1px solid #C89328;
            text-transform: uppercase;
            background: #C89328;">
            delete</button>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- delete modal end -->
@endsection