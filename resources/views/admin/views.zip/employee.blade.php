@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Employee')

@section('content')
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<h2 class="table-cap pb-1">Employees</h2>
	<a class="add-btn my-3" href="#" type="button">ADD NEW EMPLOYEE</a>
	<div class=" table-responsive tenant-table">
		<table class="table  table-bordered">
			<thead>
				<tr>
					<th scope="col"><span>User Name</span></th>
					<th scope="col"><span>Email</span></th>
					<th scope="col"><span>Password</span></th>
					<th scope="col"><span>Phone Number</span></th>
					<th scope="col"><span>Job Role</span></th>
					<th scope="col"><span>Access Type</span></th>
					<th scope="col"><span>Tenant ID</span></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Employee1</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>00996123456</td>
					<td>Customer Services</td>
					<td>Admin</td>
					<td>AF89435</td>
					<td class="btn-bg1"><a type="button" class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">EDIT</a> </td>
					<td class="btn-bg1 fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>

				</tr>
				<tr>
					<td>Employee 2</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>00996123456</td>
					<td>Call Center</td>
					<td>Admin</td>
					<td>AF89435</td>

					<td class="btn-bg1"><a type="button" class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">EDIT</a> </td>
					<td class="btn-bg1 fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>

				</tr>
				<tr>
					<td>Employee 3</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>00996123456</td>
					<td>Call Center</td>
					<td>Admin</td>
					<td>AF89435</td>

					<td class="btn-bg1"><a type="button" class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">EDIT</a> </td>
					<td class="btn-bg1 fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
				</tr>
				<tr>
					<td>Employee 4</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>00996123456</td>
					<td>Call Center</td>
					<td>Viewer</td>
					<td>AF89435</td>

					<td class="btn-bg1"><a type="button" class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">EDIT</a> </td>
					<td class="btn-bg1 fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!-- delete modal start -->
<div class="modal" id="remove-item" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-transparent border-0">
      <div class="modal-body">
        <div class="remove-content-wrapper">
          <p>Are you sure you want to delete?</p>
          <div class="delete-btn-wrapper">
            <a href="#" type="button" class="btn-close-modal" data-bs-dismiss="modal" aria-label="Close">cancel</a>
            <a href="#">delete</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- delete modal end -->
@endsection