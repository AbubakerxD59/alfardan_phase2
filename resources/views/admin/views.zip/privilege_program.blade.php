@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Privilage Program')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
	<h2 class="table-cap pb-1 text-capitalize">privilege program</h2>
	<a class="add-btn my-2 px-1"  type="button">Update brochure</a>
</main>

@endsection
