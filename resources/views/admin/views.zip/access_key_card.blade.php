@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Access Key Card')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Access Key Card</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-access-key-card">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Form ID</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">User Name</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Contact Number</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Card</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Submission Date</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Apartment</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Property</a></th>
					<th ><a href="access-key-card-view.html" class="w-100 d-block">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>New</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-access-key-card">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>New</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-access-key-card">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Additional</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-access-key-card">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Replacement</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-access-key-card">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add Access key model start -->
<div class="modal fade" id="add-access-key-card"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper extra-width">
						<form>
							
							<h2 class="form-caption">Add Access Key Card</h2>
							<div class="row">
								<div class="col-12  col-lg-12 col-xl-8">
									<!-- frst row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User Name</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Form ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Submission Date</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="radio-input-group">
												<h2>Card Request</h2>
												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="new" value="option2">
													<label class="form-check-label" for="new">New</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="additional" value="option2">
													<label class="form-check-label" for="additional">Additional</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="replacement" value="option2">
													<label class="form-check-label" for="replacement">Replacement</label>

													<div class="form-check form-check-block">
														<input class="form-check-input" name="card-request" type="radio" id="lost" value="option2">
														<label class="form-check-label" for="lost">Lost</label>
													</div>

													<div class="form-check form-check-block">
														<input class="form-check-input" name="card-request" type="radio" id="damaged" value="option2">
														<label class="form-check-label" for="damaged">Damaged</label>
													</div>
												</div>

												<h2>Access Type</h2>
												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="apartment" value="option2">
													<label class="form-check-label" for="apartment">Apartment</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="lift" value="option2">
													<label class="form-check-label" for="lift">Lift</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="parking" value="option2">
													<label class="form-check-label" for="parking">Parking</label>
												</div>



											</div>
										</div>
										<div class="col-sm-6 col-12">
										<label class="text-white" for="location">Property</label>
										<div class="custom-select2 form-rounded my-2">
											<select id="location">
												<option value="0" selected></option>
												<option value="1">Property 1</option>
												<option value="2">Property 2</option>
												<option value="3">Property 3</option>
												<option value="4">Property 4</option>
												<option value="5">Property 5</option>
												<option value="6">Property 6</option>
												<option value="7">Property 7</option>

											</select>
										</div>

											<label class="text-white" for="location">Apartment</label>
												<div class="custom-select2 form-rounded my-2">
												<select id="location">
													<option value="0" selected></option>
													<option value="1">Apartment 1</option>
													<option value="2">Apartment 2</option>
													<option value="3">Apartment 3</option>
													<option value="4">Apartment 4</option>
													<option value="5">Apartment 5</option>
													<option value="6">Apartment 6</option>
													<option value="7">Apartment 7</option>

												</select>
											</div>

											<div class="input-field-group">
												<label for="username">Expiry Date</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group">
												<label for="username">Quantity</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>

										</div>
									</div>
								</div>
								<div class="col-12  col-sm-6 col-md-6 col-lg-4 col-xl-4">
									<div class="profile-img-holder mb-3">
										<figcaption>User Photo</figcaption>
										<div id="add-access-key-image-preview" class="image-preview">
											<label for="add-access-key-image-upload" id="add-access-key-image-label"> ADD IMAGE</label>
											<input type="file" name="image" id="add-access-key-image-upload" />
										</div> 
									</div>

									<div class="input-field-group">
										<label for="username">Charge</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label >Remarks</label>
										<textarea class="description"></textarea>
									</div>
								</div>
							</div>

							<!-- sixth row-->
							<div class="row pt-3">
								<div class="col-12 col-sm-5">
									<div class="radio-input-group  float-start">
										<div class="form-check form-check-block">
											<input class="form-check-input" name="additionaloption" type="radio" id="additionaloption" value="option2">
											<label class="form-check-label" for="additionaloption">*Additional/replacement key card(s) are chargeable at QR. 50 per key card</label>
										</div>
									</div>
								</div>
								<div class="col-12 col-sm-6">
									<div class="btn-holder float-end">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add Access key model end -->    
<!--edit Access key model start -->
<div class="modal fade" id="edit-access-key-card"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">
		
		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper extra-width">
						<form>
							
							<h2 class="form-caption">Edit Access Key Card</h2>
							<div class="row">
								<div class="col-12  col-lg-12 col-xl-8">
									<!-- frst row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User Name</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Form ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Submission Date</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="radio-input-group">
												<h2>Card Request</h2>
												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="new" value="option2">
													<label class="form-check-label" for="new">New</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="additional" value="option2">
													<label class="form-check-label" for="additional">Additional</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="card-request" type="radio" id="replacement" value="option2">
													<label class="form-check-label" for="replacement">Replacement</label>

													<div class="form-check form-check-block">
														<input class="form-check-input" name="card-request" type="radio" id="lost" value="option2">
														<label class="form-check-label" for="lost">Lost</label>
													</div>

													<div class="form-check form-check-block">
														<input class="form-check-input" name="card-request" type="radio" id="damaged" value="option2">
														<label class="form-check-label" for="damaged">Damaged</label>
													</div>
												</div>

												<h2>Access Type</h2>
												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="apartment" value="option2">
													<label class="form-check-label" for="apartment">Apartment</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="lift" value="option2">
													<label class="form-check-label" for="lift">Lift</label>
												</div>

												<div class="form-check form-check-block">
													<input class="form-check-input" name="access-type" type="radio" id="parking" value="option2">
													<label class="form-check-label" for="parking">Parking</label>
												</div>



											</div>
										</div>
										<div class="col-sm-6 col-12">
										<label class="text-white" for="location">Property</label>
										<div class="custom-select2 form-rounded my-2">
											<select id="location">
												<option value="0" selected></option>
												<option value="1">Property 1</option>
												<option value="2">Property 2</option>
												<option value="3">Property 3</option>
												<option value="4">Property 4</option>
												<option value="5">Property 5</option>
												<option value="6">Property 6</option>
												<option value="7">Property 7</option>

											</select>
										</div>

										<label class="text-white" for="location">Apartment</label>
												<div class="custom-select2 form-rounded my-2">
												<select id="location">
													<option value="0" selected></option>
													<option value="1">Apartment 1</option>
													<option value="2">Apartment 2</option>
													<option value="3">Apartment 3</option>
													<option value="4">Apartment 4</option>
													<option value="5">Apartment 5</option>
													<option value="6">Apartment 6</option>
													<option value="7">Apartment 7</option>

												</select>
											</div>

											<div class="input-field-group">
												<label for="username">Expiry Date</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group">
												<label for="username">Quantity</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>

										</div>
									</div>
								</div>
								<div class="col-12  col-sm-6 col-md-6 col-lg-4 col-xl-4">
									<div class="profile-img-holder mb-3">
										<figcaption>User Photo</figcaption>
										<div id="edit-access-key-image-preview" class="image-preview">
											<label for="edit-access-key-image-upload" id="edit-access-key-image-label">EDIT IMAGE </label>
											<input type="file" name="image" id="edit-access-key-image-upload" />
										</div> 
									</div>

									<div class="input-field-group">
										<label for="username">Charge</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label >Remarks</label>
										<textarea class="description"></textarea>
									</div>
								</div>
							</div>
							
							<!-- sixth row-->
							<div class="row pt-3">
								<div class="col-12 col-sm-5">
									<div class="radio-input-group  float-start">
										<div class="form-check form-check-block">
											<input class="form-check-input" name="additionaloption" type="radio" id="additionaloption" value="option2">
											<label class="form-check-label" for="additionaloption">*Additional/replacement key card(s) are chargeable at QR. 50 per key card</label>
										</div>
									</div>
								</div>
								<div class="col-12 col-sm-6">
									<div class="btn-holder float-end">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
	</div>
</div>
<!--Edit Access key model start -->    
@endsection
