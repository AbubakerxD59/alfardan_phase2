@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Family Member')

@section('content')
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
	<h2 class="table-cap pb-1">Family Members</h2>
	<a class="add-btn my-3" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#addfamilymember">ADD NEW USER</a>
	<div class=" table-responsive tenant-table">
		<table class="table  table-bordered">
			<thead>
				<tr>
					<th scope="col"><span>User Name</span></th>
					<th scope="col"><span>Email</span></th>
					<th scope="col"><span>Password</span></th>
					<th scope="col"><span>Account Status</span></th>
					<th scope="col"><span>Date of Birth</span></th>
					<th scope="col"><span>Phone Number</span></th>
					<th scope="col"><span>Tel. Number</span></th>
					<th scope="col"><span>Leasing Type</span></th>
					<th scope="col"><Span>Tenant Type</Span></th>
					<th scope="col"><span>Property</span></th>
					<th scope="col"><span>Apartment</span></th>
					<th scope="col"><span>No. Of Members</span></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><a href="{{route('admin.family_member_view')}}">User 1 </a></td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>Active</td>
					<td>20/08/1994</td>
					<td>00996123456</td>
					<td>00996123456</td>
					<td>Corporate</td>
					<td>Regular</td>
					<td>Property 1</td>
					<td>Apartment A Apartment B</td>
					<td>10</td>
					<td  class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editfamilymember">EDIT </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>
				<tr>
					<td>Company 1</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>Active</td>
					<td>20/08/1994</td>
					<td>00996123456</td>
					<td>00996123456</td>
					<td>Corporate</td>
					<td>Regular</td>
					<td>Property 1</td>
					<td>Apartment A</td>
					<td>1</td>
					<td  class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editfamilymember">EDIT </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>

				</tr>
				<tr>
					<td>User 2</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>Inactive</td>
					<td>20/08/1994</td>
					<td>00996123456</td>
					<td>00996123456</td>
					<td>Individual</td>
					<td>Regular</td>
					<td>Property 1</td>
					<td>Apartment A</td>
					<td>2</td>
					<td class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editfamilymember">EDIT </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>
				<tr>
					<td>User 3</td>
					<td>fsdfa@gmail.com</td>
					<td>******</td>
					<td>Inactive</td>
					<td>20/08/1994</td>
					<td>00996123456</td>
					<td>00996123456</td>
					<td>Individual</td>
					<td>VIP</td>
					<td>Property 1</td>
					<td>Apartment A</td>
					<td>4</td>
					<td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#editfamilymember">EDIT </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>
			</tbody>
		</table>
	</div> 
</main>
<!--add family member model start -->
<div class="modal fade" id="addfamilymember"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    
    <div class="modal-content">
      <div class="modal-body profile-model">
        <div class="container-fluid px-0">
          <div class="row">
            <div class="col-12">
              <div class="body-wrapper">
                <h2 class="table-cap pb-2 text-capitalize mb-3 ms-2 mt-3 ">Add Family Member</h2>
            
                <form>
                  <div class="row">
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4  ">
                      <div class="add-family-form-wrapper ps-2 pe-3">
                        <label>User Name</label>
                        <input  type="text" name="username">
                        <label>Email</label>
                        <input  type="email" name="username">
                        <label>Phone Number</label>
                        <input  type="text" name="username">
                        <label>Tenant Name</label>
                        <input  type="text" name="username">
                        <label>Property</label>
                        <input  type="text" name="username">
                        <label>Apartment</label>
                        <input  type="text" name="username">
                        
                      </div>
                    </div>
                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8 ps-4 label-size">
                      <div class="profile-img-holder add-event-img-holder  mb-3">
                        <figcaption>Images</figcaption>
                        <div id="add-family-img-preview-modal" class="image-preview">
                          <label class="text-uppercase" for="add-family-img-upload-modal" id="add-family-img-label-modal">add image</label>
                          <input type="file" name="image" id="add-family-img-upload-modal" />
                        </div>
                      </div>
                      <h2>Tenant</h2>
                      <div class="profile-tenant-form">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" id="inlineCheckbox1" name="tenantinput" value="option1">
                          <label class="form-check-label" for="inlineCheckbox1">VIP</label>
                        </div>
                        
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox2" value="option2">
                          <label class="form-check-label" for="inlineCheckbox2">Regular</label>
                        </div>
                        
                        <div class="form-check form-check-inline mb-2">
                          <input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox3" value="option3">
                          <label class="form-check-label" for="inlineCheckbox3">Non-Tenant</label>
                        </div>
                        
                        <h2>Property</h2>
                        <div class="property-input-wrapper">
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property1" value="option1">
                            <label class="form-check-label" for="Property1">Property 1</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property2" value="option2">
                            <label class="form-check-label" for="Property2">Property 2</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property3" value="option3">
                            <label class="form-check-label" for="Property3">Property 3</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property4" value="option4">
                            <label class="form-check-label" for="Property4">Property 4</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property5" value="option4">
                            <label class="form-check-label" for="Property5">Property 5</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property6" value="option6">
                            <label class="form-check-label" for="Property6">Property 6</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property7" value="option7">
                            <label class="form-check-label" for="Property7">Property 7</label>
                          </div>
                        </div>
                        <div class="form-btn-holder mb-3 text-end  me-xxl-0">
                          <button class="form-btn">Publish</button>
                          <button class="form-btn">Draft</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>
</div>
<!--add family member model end -->
<!--edit family member model start -->
<div class="modal fade" id="editfamilymember"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    
    <div class="modal-content">             
      <div class="modal-body profile-model">
        <div class="container-fluid px-0">
          <div class="row">
            <div class="col-12">
              <div class="body-wrapper">
                <h2 class="table-cap pb-2 text-capitalize mb-3 ms-2 mt-3 ">Edit Family Member</h2>
                
                <form>
                  <div class="row">
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4  ">
                      <div class="add-family-form-wrapper ps-2 pe-3">
                        <label>User Name</label>
                        <input  type="text" name="username">
                        <label>Email</label>
                        <input  type="email" name="username">
                        <label>Phone Number</label>
                        <input  type="text" name="username">
                        <label>Tenant Name</label>
                        <input  type="text" name="username">
                        <label>Property</label>
                        <input  type="text" name="username">
                        <label>Apartment</label>
                        <input  type="text" name="username">
                      </div>
                    </div>
                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8 ps-4 label-size">
                      <div class="profile-img-holder add-event-img-holder  mb-3">
                        <figcaption>Images</figcaption>
                        <div id="edit-family-img-preview-modal" class="image-preview">
                          <label class="text-uppercase" for="edit-family-img-upload-modal" id="edit-family-img-label-modal"> EDIT IMAGE</label>
                          <input type="file" name="image" id="edit-family-img-upload-modal" />
                        </div>
                      </div>
                      <h2>Tenant</h2>
                      <div class="profile-tenant-form">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" id="inlineCheckbox1" name="tenantinput" value="option1">
                          <label class="form-check-label" for="inlineCheckbox1">VIP</label>
                        </div>
                        
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox2" value="option2">
                          <label class="form-check-label" for="inlineCheckbox2">Regular</label>
                        </div>
                        
                        <div class="form-check form-check-inline mb-2">
                          <input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox3" value="option3">
                          <label class="form-check-label" for="inlineCheckbox3">Non-Tenant</label>
                        </div>
                        
                        <h2>Property</h2>
                        <div class="property-input-wrapper">
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property1" value="option1">
                            <label class="form-check-label" for="Property1">Property 1</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property2" value="option2">
                            <label class="form-check-label" for="Property2">Property 2</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property3" value="option3">
                            <label class="form-check-label" for="Property3">Property 3</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property4" value="option4">
                            <label class="form-check-label" for="Property4">Property 4</label>
                          </div>
                          
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" name="property" type="radio" id="Property5" value="option4">
                            <label class="form-check-label" for="Property5">Property 5</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property6" value="option6">
                            <label class="form-check-label" for="Property6">Property 6</label>
                          </div>
                          
                          <div class="form-check form-check-inline mb-2">
                            <input class="form-check-input" name="property" type="radio" id="Property7" value="option7">
                            <label class="form-check-label" for="Property7">Property 7</label>
                          </div>
                        </div>
                        <div class="form-btn-holder mb-3 text-end  me-xxl-0">
                          <button class="form-btn">Publish</button>
                          <button class="form-btn">Draft</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>
</div>
<!--add family member model end -->
@endsection
