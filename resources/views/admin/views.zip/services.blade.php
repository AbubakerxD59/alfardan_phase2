@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Services')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Services</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-services">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered " style="width: 1100px;">
			<thead>
				<tr>
					<th ><a href="service-view.html" class="d-block w-100"> Form ID</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> User Name</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Contact Number</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Service Type</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Submission Date</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Availability Date</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Apartment</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Property</a></th>
					<th ><a href="service-view.html" class="d-block w-100"> Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Car Wash</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-services">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Trolly</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-services">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Cleaning</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-services">Edit </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Laundry</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-services">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">REMOVE</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add service form model start -->
<div class="modal fade" id="add-services"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">add services</h2>
							
							<!-- frst row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="userid">User ID</label>
										<input type="text" name="username" id="userid">
									</div>
								</div>
							</div>

							<!-- scnd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="formid">Form ID</label>
										<input type="text" name="username" id="formid">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="submission">Submission Date</label>
										<input type="text" name="username" id="submission">
									</div>
								</div>
							</div>

							<!-- thrd row -->
							<div class="row">
								<div class="col-sm-6 col-12 pt-2">
									<div class="input-field-group">
										<label for="availability">Availability Date</label>
										<input type="text" name="username" id="availability">
									</div>
								</div>
								<div class="col-sm-6 col-12">
								
									<label class="text-white" for="service">service Type</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="service">
											<option value="0" selected></option>
											<option value="1">Service Type 1</option>
											<option value="2">Service Type 2</option>
											<option value="3">Service Type 3</option>
											<option value="4">Service Type 4</option>
											<option value="5">Service Type 5</option>
											<option value="6">Service Type 6</option>
											<option value="7">Service Type 7</option>

										</select>
									</div>
									
								</div>
							</div>

							<!-- frth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
								
									<label class="text-white" for="Property">Property</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="Property">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>
									
								</div>
								<div class="col-sm-6 col-12">
								
									<label class="text-white" for="Property">Property</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="Property">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>
								</div>
							</div>

							<!-- fifth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="Attendee">Attendee Name</label>
										<input type="text" name="username" id="Attendee">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="Status">Status</label>
										<input type="text" name="username" id="Status">
									</div>
								</div>
							</div>

							<!-- sixth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="StatusReason">Status Reason</label>
										<textarea class="description" id="StatusReason"></textarea>
									</div>
								</div>
							</div>

							<!-- sevnth row -->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add service form model end -->  
<!--edit service form model start -->
<div class="modal fade" id="edit-services"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">
		
		<div class="modal-content border-0 bg-transparent">             
			<div class="modal-body  service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">edit services</h2>
					
							<!-- frst row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="userid">User ID</label>
										<input type="text" name="username" id="userid">
									</div>
								</div>
							</div>

							<!-- scnd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="formid">Form ID</label>
										<input type="text" name="username" id="formid">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="Submissiondate">Submission Date</label>
										<input type="text" name="username" id="Submissiondate">
									</div>
								</div>
							</div>

							<!-- thrd row -->
							<div class="row">
								<div class="col-sm-6 col-12 pt-2">
									<div class="input-field-group">
										<label for="Availabilitydate">Availability Date</label>
										<input type="text" name="username" id="Availabilitydate">
									</div>
								</div>
								<div class="col-sm-6 col-12">
								<label class="text-white" for="Services">Services Type</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="Services">
											<option value="0" selected></option>
											<option value="1">Service Type 1</option>
											<option value="2">Service Type 2</option>
											<option value="3">Service Type 3</option>
											<option value="4">Service Type 4</option>
											<option value="5">Service Type 5</option>
											<option value="6">Service Type 6</option>
											<option value="7">Service Type 7</option>

										</select>
									</div>
								</div>
							</div>

							<!-- frth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
								<label class="text-white" for="Apartment">Apartment</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="Apartment">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>
								</div>
								<div class="col-sm-6 col-12">
								<label class="text-white" for="Property">Property</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="Property">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>
								</div>
							</div>

							<!-- fifth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="Attendeename">Attendee Name</label>
										<input type="text" name="username" id="Attendeename">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="Status">Status</label>
										<input type="text" name="username" id="Status">
									</div>
								</div>
							</div>

							<!-- sixth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="Statusreason">Status Reason</label>
										<textarea class="description" id="Statusreason"></textarea>
									</div>
								</div>
							</div>

							<!-- sevnth row -->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
	</div>
</div>
<!--Edit service form model start -->      
@endsection
