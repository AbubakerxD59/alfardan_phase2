@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Vehicle Form')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Vehicle Form</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-maintenance-abtentia">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Form ID</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">User Name</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Contact Number</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Vehicle Name</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Registration Number</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Parking Space Number</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Submission Date</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Apartment</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Property</a></th>
					<th ><a href="vehicle-form-view.html" class="w-100 d-block">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>123214</td>
					<td>134</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-maintenance-abtentia">Edit </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>123214</td>
					<td>134</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-maintenance-abtentia">Edit </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>123214</td>
					<td>134</td>>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-maintenance-abtentia">Edit </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>123214</td>
					<td>134</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-maintenance-abtentia">Edit </td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add vehicle form model start -->
<div class="modal fade" id="add-maintenance-abtentia"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent" >
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<button type="button" class="btn-close-modal float-sm-end float-start mt-0 me-sm-0 me-4" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
							<h2 class="form-caption">Add Vehicle form</h2>
							<!-- frst row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User ID</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- scnd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Form ID</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Submission Date</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- thrd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Model</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- frth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Color</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Registration Number</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- fifth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Parking Space</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="custom-drop">
										<label>Property</label>
										<select id="add-vehicle-form-apartment">
											<option value="">--choose a Property--</option>
											<option value="Anubis">Property 1</option>
											<option value="Canterbury">Property 2</option>
											<option value="Donnager">Property 3</option>
											<option value="Knight">Property 4</option>
											<option value="Nauvoo">Property 5</option>
											<option value="Rocinante">Property 6</option>
											<option value="Scopuli">Property 7</option>
										</select>
									</div>
								</div>
							</div>

							<!-- sixth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="custom-drop">
										<label>Apartment</label>
										<select id="add-vehicle-form-property">
											<option value="">--choose a Maintenance--</option>
											<option value="Anubis">Apartment 1</option>
											<option value="Canterbury">Apartment 2</option>
											<option value="Donnager">Apartment 3</option>
											<option value="Knight">Apartment 4</option>
											<option value="Nauvoo">Apartment 5</option>
											<option value="Rocinante">Apartment 6</option>
											<option value="Scopuli">Apartment 7</option>
										</select>
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Phone Number</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- sevnth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="username">Status</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label >Status Reason</label>
										<textarea class="description"></textarea>
									</div>
								</div>
							</div>

							<!-- eighth row -->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add vehicle form model end -->
<!--edit vehicle form model start -->
<div class="modal fade" id="edit-maintenance-abtentia"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<button type="button" class="btn-close-modal float-sm-end float-start mt-0 me-sm-0 me-4" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
							<h2 class="form-caption">Edit Vehicle form</h2>
							<!-- frst row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">User ID</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- scnd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Form ID</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Submission Date</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- thrd row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Name</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Model</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- frth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Vehicle Color</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Registration Number</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- fifth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Parking Space</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="custom-drop">
										<label>Property</label>
										<select id="edit-vehicle-form-property">
											<option value="">--choose a Property--</option>
											<option value="Anubis">Property 1</option>
											<option value="Canterbury">Property 2</option>
											<option value="Donnager">Property 3</option>
											<option value="Knight">Property 4</option>
											<option value="Nauvoo">Property 5</option>
											<option value="Rocinante">Property 6</option>
											<option value="Scopuli">Property 7</option>
										</select>
									</div>
								</div>
							</div>

							<!-- sixth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="custom-drop">
										<label>Apartment</label>
										<select id="edit-vehicle-form-apartment">
											<option value="">--choose a Maintenance--</option>
											<option value="Anubis">Apartment 1</option>
											<option value="Canterbury">Apartment 2</option>
											<option value="Donnager">Apartment 3</option>
											<option value="Knight">Apartment 4</option>
											<option value="Nauvoo">Apartment 5</option>
											<option value="Rocinante">Apartment 6</option>
											<option value="Scopuli">Apartment 7</option>
										</select>
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label for="username">Phone Number</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
							</div>

							<!-- sevnth row -->
							<div class="row">
								<div class="col-sm-6 col-12">
									<div class="input-field-group pb-4">
										<label for="username">Status</label>
										<input type="text" name="username" id="username">
									</div>
								</div>
								<div class="col-sm-6 col-12">
									<div class="input-field-group">
										<label >Status Reason</label>
										<textarea class="description"></textarea>
									</div>
								</div>
							</div>

							<!-- eighth row -->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Edit vehicle form model start -->

@endsection
