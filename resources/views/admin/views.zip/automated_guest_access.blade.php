@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Automated Guest Access')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Automated Guest Access</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-automated-guest">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Form ID</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">User Name</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Contact Number</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Authorized Person Name</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Submission Date</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Access Date</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Apartment</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Property</a></th>
					<th ><a class="w-100 d-block" href="automated-guest-view.html">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-automated-guest">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-automated-guest">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-automated-guest">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Name</td>
					<td>11/12/2021</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td  class="fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-automated-guest">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add pet request model start -->
<div class="modal fade" id="add-automated-guest"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper extra-width">
						<form>
							<button type="button" class="btn-close-modal float-sm-end mt-0  me-4 me-sm-0 float-start " data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
							<h2 class="form-caption">Add Maintenance in absentia</h2>

							<div class="row">
								<div class="col-12  col-lg-12 col-xl-8">
									<!-- frst row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User Name</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Form ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Submission Date</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Authorized Person Number</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Access Date & Time</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>


									<!-- thrd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="custom-drop">
												<label>Apartment</label>
												<select id="add-automated-guest-apartment">
													<option value="">--choose a Maintenance--</option>
													<option value="Anubis">Apartment 1</option>
													<option value="Canterbury">Apartment 2</option>
													<option value="Donnager">Apartment 3</option>
													<option value="Knight">Apartment 4</option>
													<option value="Nauvoo">Apartment 5</option>
													<option value="Rocinante">Apartment 6</option>
													<option value="Scopuli">Apartment 7</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="custom-drop">
												<label>Property</label>
												<select id="add-automated-guest-property">
													<option value="">--choose a Property--</option>
													<option value="Anubis">Property 1</option>
													<option value="Canterbury">Property 2</option>
													<option value="Donnager">Property 3</option>
													<option value="Knight">Property 4</option>
													<option value="Nauvoo">Property 5</option>
													<option value="Rocinante">Property 6</option>
													<option value="Scopuli">Property 7</option>
												</select>
											</div>
										</div>
									</div>

									<!-- frth row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Phone Number</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- fifth row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group pt-sm-5">
												<input class="form-check-input" type="radio" name="radio" id="condition"> <span for="condition" class="input-radio-checked">Terms & Conditions</span>
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label >Status Reason</label>
												<textarea class="description"></textarea>
											</div>
										</div>
									</div>
								</div>
								<div class="col-12  col-sm-6 col-md-6 col-lg-4 col-xl-4">
									<div class="profile-img-holder mb-3">
										<figcaption>Authorized Person ID Photo</figcaption>
										<div id="add-automated-guest-image-preview" class="image-preview">
											<label for="add-automated-guest-image-upload" id="add-automated-guest-image-label">Choose File</label>
											<input type="file" name="image" id="add-automated-guest-image-upload" />
										</div> 
									</div>
								</div>
							</div>

							<!-- sixth row-->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add pet request model end -->  
<!--edit pet request model start -->
<div class="modal fade" id="edit-automated-guest"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">
		
		<div class="modal-content border-0 bg-transparent" >
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper extra-width">
						<form>
							<button type="button" class="btn-close-modal float-sm-end mt-0  me-4 me-sm-0 float-start " data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
							<h2 class="form-caption">Add Maintenance in absentia</h2>
							<div class="row">
								<div class="col-12  col-lg-12 col-xl-8">
									<!-- frst row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User Name</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">User ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Form ID</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Submission Date</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- scnd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Authorized Person Number</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Access Date & Time</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>


									<!-- thrd row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="custom-drop">
												<label>Apartment</label>
												<select id="edit-automated-guest-apartment">
													<option value="">--choose a Maintenance--</option>
													<option value="Anubis">Apartment 1</option>
													<option value="Canterbury">Apartment 2</option>
													<option value="Donnager">Apartment 3</option>
													<option value="Knight">Apartment 4</option>
													<option value="Nauvoo">Apartment 5</option>
													<option value="Rocinante">Apartment 6</option>
													<option value="Scopuli">Apartment 7</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="custom-drop">
												<label>Property</label>
												<select id="edit-automated-guest-property">
													<option value="">--choose a Property--</option>
													<option value="Anubis">Property 1</option>
													<option value="Canterbury">Property 2</option>
													<option value="Donnager">Property 3</option>
													<option value="Knight">Property 4</option>
													<option value="Nauvoo">Property 5</option>
													<option value="Rocinante">Property 6</option>
													<option value="Scopuli">Property 7</option>
												</select>
											</div>
										</div>
									</div>

									<!-- frth row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Phone Number</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- fifth row -->
									<div class="row">
										<div class="col-sm-6 col-12">
											<div class="input-field-group pt-sm-5">
												<input class="form-check-input" type="radio" name="radio" id="condition"> <span for="condition" class="input-radio-checked">Terms & Conditions</span>
											</div>
										</div>
										<div class="col-sm-6 col-12">
											<div class="input-field-group">
												<label >Status Reason</label>
												<textarea class="description"></textarea>
											</div>
										</div>
									</div>
								</div>
								<div class="col-12  col-sm-6 col-md-6 col-lg-4 col-xl-4">
									<div class="profile-img-holder mb-3">
										<figcaption>Authorized Person ID Photo</figcaption>
										<div id="edit-automated-guest-image-preview" class="image-preview">
											<label for="edit-automated-guest-image-upload" id="edit-automated-guest-image-label">Choose File</label>
											<input type="file" name="image" id="edit-automated-guest-image-upload" />
										</div> 
									</div>
								</div>
							</div>
							
							<!-- sixth row-->
							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
	</div>
</div>
<!--Edit pet request model start -->      
@endsection
