@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Circular Update')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Circular Update</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-circular-update">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th><a href="circular-update-view.html" class="w-100 d-block">Circular ID</a></th>
					<th><a href="circular-update-view.html" class="w-100 d-block">Submission Date</a></th>
					<th><a href="circular-update-view.html" class="w-100 d-block">Survey Link</a></th>
					<th><a href="circular-update-view.html" class="w-100 d-block">Apartment</a></th>
					<th><a href="circular-update-view.html" class="w-100 d-block">Property</a></th>
					<th><a href="circular-update-view.html" class="w-100 d-block">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>11/12/2021</td>
					<td>Link</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td class="table-edit fw-bold cursor-pointer"  data-bs-toggle="modal" data-bs-target="#edit-circular-update">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>11/12/2021</td>
					<td>Link</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="cursor-pointer table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#edit-circular-update">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>11/12/2021</td>
					<td>Link</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="cursor-pointer table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#edit-circular-update">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>11/12/2021</td>
					<td>Link</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td class="table-edit fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-circular-update">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add circular-update form model start -->
<div class="modal fade" id="add-circular-update"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content bg-transparent border-0" >
			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">Add Circular</h2>
					
							<div class="row">
								<div class="col-12 col-sm-6">

									<div class="input-field-group">
										<label for="username">Cicular ID</label>
										<input type="text" name="username" id="username">
									</div>

									<label class="text-white" for="location">Properties</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Apartments</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>

									<div class="profile-img-holder mb-3">
										<figcaption>Circular Image</figcaption>
										<div id="add-circular-image-preview" class="image-preview">
											<label for="add-circular-image-upload" id="add-circular-image-label">ADD IMAGE </label>
											<input type="file" name="image" id="add-circular-image-upload" />
										</div> 
									</div>

								</div>

								<div class="col-12 col-sm-6">

									<div class="profile-img-holder mb-3">
										<figcaption>Description Image</figcaption>
										<div id="add-circular-image-preview1" class="image-preview">
											<label for="add-circular-image-upload1" id="add-circular-image-label1">ADD IMAGE </label>
											<input type="file" name="image" id="add-circular-image-upload1" />
										</div> 
									</div>

									<div class="input-field-group">
										<label >Description</label>
										<textarea class="description mb-1"></textarea>
									</div>

								</div>
							</div>

							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add circular-update form model end --> 
<!--edit circular-update form model start -->
<div class="modal fade" id="edit-circular-update"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">
		
		<div class="modal-content bg-transparent border-0">              
			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">Edit Circular</h2>
							
							<div class="row">
								<div class="col-12 col-sm-6">

									<div class="input-field-group">
										<label for="username">Cicular ID</label>
										<input type="text" name="username" id="username">
									</div>

									<label class="text-white" for="location">Properties</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Apartments</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>

									<div class="profile-img-holder mb-3">
										<figcaption>Circular Image</figcaption>
										<div id="edit-circular-image-preview" class="image-preview">
											<label for="edit-circular-image-upload" id="edit-circular-image-label">EDIT IMAGE </label>
											<input type="file" name="image" id="edit-circular-image-upload" />
										</div> 
									</div>

								</div>

								<div class="col-12 col-sm-6">

									<div class="profile-img-holder mb-3">
										<figcaption>Description Image</figcaption>
										<div id="edit-circular-image-preview1" class="image-preview">
											<label for="edit-circular-image-upload1" id="edit-circular-image-label1">EDIT IMAGE </label>
											<input type="file" name="image" id="edit-circular-image-upload1" />
										</div> 
									</div>

									<div class="input-field-group">
										<label >Description</label>
										<textarea class="description mb-1"></textarea>
									</div>

								</div>
							</div>

							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</div>
		
		
	</div>
</div>
<!--Edit circular-update form model start -->       
@endsection
