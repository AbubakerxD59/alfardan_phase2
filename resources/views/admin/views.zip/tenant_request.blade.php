@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Tenant Request')

@section('content')
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
@include('notification.notify')

	<h2 class="table-cap pb-1 mb-2">Become Tenant Requests</h2>

	<!-- <a class="add-btn my-3" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-btn-model">ADD NEW EMPLOYEE</a> -->
	<div class=" table-responsive tenant-table tanent-request-wrapper">
		<table class="table  table-bordered" id="myTable">
			<thead>
				<tr>
					<th>First Name</th>
         			<th>Last Name</th>
					<th scope="col"><span>Email</span></th>
					<!-- <th scope="col"><span>Password</span></th> -->
					<th scope="col"><span>Date of Birth</span></th>
					<!-- <th scope="col"><span>Start Date</span></th> -->
					<th scope="col"><span>Phone Number</span></th>
					<!-- <th scope="col"><span>Tenant Type</span></th> -->
					<!-- <th scope="col"><span>Leasing Type</span></th> -->
					<th scope="col"><span>Property</span></th>
					<th scope="col"><span>Apartment</span></th>
					<!-- <th scope="col"><span>Tenant Name</span></th> -->
					<th scope="col"><span>Date Submitted</span></th>
					<th scope="col"><span>Accept</span></th>
					<th scope="col"><span>Reject</span></th>
					<th scope="col"><span>Edit</span></th>
				</tr>
			</thead>
			<tbody>
				@foreach ($users as $key => $user)
				<tr>
					<td>{{$user->first_name}}</td>
					<td>{{$user->last_name}}</td>
					<td>{{$user->email}}</td>
					<td>{{$user->dob}}</td>
					<td>{{$user->mobile}}</td>
					<td>{{$user->property}}</td>
					<td>{{$user->apt_number}}</td>
					<td>{{$user->created_at}}</td>
					<td class="tenant-request-btn text-capitalize">
						<a href="{{route('admin.accept_tenant_request', $user->id)}}" type="submit" class="table-edit fw-bold">accept</a> 
					</td>	
					<td>
						<button class="btn-bg2 text-capitalize" data-bs-toggle="modal" data-bs-target="#reject-item"  title='Reject' data-userid="{{$user->id}}" style="background: none;border: none;color: #fff;">reject</button>
					</td>
					<td class="tenant-request-btn text-capitalize"><a  type="button" class="table-delete fw-bold">edit</a></td>

				</tr>
				@endforeach

			</tbody>
		</table>
	</div>

</main>
<!-- Rejection  modal start -->
<div class="modal" id="reject-item" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-transparent border-0">
      <div class="modal-body">
        <div class="reject-content-wrapper">
	    	<form method="post" action="{{route('admin.reject_tenant_request','user')}}">
	          {{csrf_field()}}
	          <input type="hidden" name="userid" id="userid" value="">
	          <label>Reason For Rejection</label>
	          <textarea name="rejection_reason"></textarea>
	          <div class="reject-btn-wrapper">
	            <a href="#" type="button" class="btn-close-modal" data-bs-dismiss="modal" aria-label="Close">cancel</a>
	            <!-- <a href="#">send</a> -->
	            <button type="Submit" 
	            style="color: #fff;
	            font-size: 18px;
	            max-width: 133px;
	            height: 37px;
	            padding: 7px 32px;
	            border: 1px solid #C89328;
	            text-transform: uppercase;
	            background: #C89328;">
	            send</button>
         	  </div>
         	</form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Rejection modal end -->
@endsection