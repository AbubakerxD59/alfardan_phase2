@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Complaints')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Complaints</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-complaint">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th><a href="complaint-chat-view.html">Complaint ID</a></th>
					<th><a href="complaint-chat-view.html">User Name</a></th>
					<th><a href="complaint-chat-view.html">Contact Number</a></th>
					<th><a href="complaint-chat-view.html">Complain Type</a></th>
					<th><a href="complaint-chat-view.html">Submission Date</a></th>
					<th><a href="complaint-chat-view.html">Apartment</a></th>
					<th><a href="complaint-chat-view.html">Property</a></th>
					<th><a href="complaint-chat-view.html">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Complain Type</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="table-edit fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-complaint">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Complain Type</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="table-edit fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-complaint">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Complain Type</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Approved</td>
					<td  class="table-edit fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-complaint">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>9815</td>
					<td>Name</td>
					<td>19314913</td>
					<td>Complain Type</td>
					<td>11/12/2021</td>
					<td>Apartment</td>
					<td>Property</td>
					<td>Declined</td>
					<td  class="table-edit fw-bold cursor-pointer" data-bs-toggle="modal" data-bs-target="#edit-complaint">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add complaint form model start -->
<div class="modal fade" id="add-complaint"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content" style="border: 0; background-color: #444444;">
			<div class="modal-header border-0">
				
			</div>

			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">add complaint</h2>
							<div class="row">
								<div class="col-12 col-sm-6">

									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label for="username">User ID</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label for="username">Form ID</label>
										<input type="text" name="username" id="username">
									</div>

									<label class="text-white" for="location">Complaint Type</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Complaint 1</option>
											<option value="2">Complaint 2</option>
											<option value="3">Complaint 3</option>
											<option value="4">Complaint 4</option>
											<option value="5">Complaint 5</option>
											<option value="6">Complaint 6</option>
											<option value="7">Complaint 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Property Name</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Apartment</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>

								<label class="text-white" for="location">Status</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Status 1</option>
											<option value="2">Status 2</option>
											<option value="3">Status 3</option>
											<option value="4">Status 4</option>
											<option value="5">Status 5</option>
											<option value="6">Status 6</option>
											<option value="7">Status 7</option>

										</select>
									</div>

								</div>

								<div class="col-12 col-sm-6">
									<div class="input-field-group">
										<label for="username">Phone Number</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="profile-img-holder mb-3">
										<figcaption>Images</figcaption>
										<div id="add-complaint-image-preview" class="image-preview">
											<label for="add-complaint-image-upload" id="add-complaint-image-label">ADD IMAGE </label>
											<input type="file" name="image" id="add-complaint-image-upload" />
										</div> 
									</div>

									<div class="input-field-group">
										<label >Description</label>
										<textarea class="description mb-1"></textarea>
									</div>

								</div>
							</div>

							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add complaint form model end -->
<!--edit complaint form model start -->
<div class="modal fade" id="edit-complaint"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content" style="border: 0; background-color: #444444;">
			<div class="modal-header border-0">
				
			</div>

			<div class="modal-body service-select">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper">
						<form>
							<h2 class="form-caption">Edit complaint</h2>
							<div class="row">
								<div class="col-12 col-sm-6">

									<div class="input-field-group">
										<label for="username">User Name</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label for="username">User ID</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="input-field-group">
										<label for="username">Form ID</label>
										<input type="text" name="username" id="username">
									</div>

									
									<label class="text-white" for="location">Complaint Type</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Complaint 1</option>
											<option value="2">Complaint 2</option>
											<option value="3">Complaint 3</option>
											<option value="4">Complaint 4</option>
											<option value="5">Complaint 5</option>
											<option value="6">Complaint 6</option>
											<option value="7">Complaint 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Property Name</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Apartment</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Apartment 1</option>
											<option value="2">Apartment 2</option>
											<option value="3">Apartment 3</option>
											<option value="4">Apartment 4</option>
											<option value="5">Apartment 5</option>
											<option value="6">Apartment 6</option>
											<option value="7">Apartment 7</option>

										</select>
									</div>

									<label class="text-white" for="location">Status</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Status 1</option>
											<option value="2">Status 2</option>
											<option value="3">Status 3</option>
											<option value="4">Status 4</option>
											<option value="5">Status 5</option>
											<option value="6">Status 6</option>
											<option value="7">Status 7</option>

										</select>
									</div>

								</div>

								<div class="col-12 col-sm-6">
									<div class="input-field-group">
										<label for="username">Phone Number</label>
										<input type="text" name="username" id="username">
									</div>

									<div class="profile-img-holder mb-3">
										<figcaption>Images</figcaption>
										<div id="edit-complaint-image-preview" class="image-preview">
											<label for="edit-complaint-image-upload" id="edit-complaint-image-label">EDIT IMAGE </label>
											<input type="file" name="image" id="edit-complaint-image-upload" />
										</div> 
									</div>

									<div class="input-field-group">
										<label >Description</label>
										<textarea class="description mb-1"></textarea>
									</div>

								</div>
							</div>

							<div class="row">
								<div class="col-12">
									<div class="btn-holder">
										<a href="#">Publish</a>
										<a href="#">Draft</a>
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Edit complaint form model start -->
@endsection
