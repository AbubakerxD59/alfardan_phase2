@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Alfardan Living Profile')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position border border-primary">
	<div class="row">
		<div class="col-xxl-6 col-xl-6 col-12">
			<h2 class="table-cap  mb-2">Alfardan Living Profile</h2>
			<div class="alfarada-living-wrapper">
				<form>
					<div class="row">
						<div class="col-xxl-5 col-xl-5 col-lg-4 col-md-5 col-sm-5 ">
							<div class="profile-img-holder mb-3">
								<figcaption>Image 1</figcaption>
								<div id="alfarada-img1-preview" class="image-preview">
									<label for="alfarada-img1-upload" id="alfarada-img1-label">EDIT IMAGE</label>
									<input type="file" name="image" id="alfarada-img1-upload" />
								</div> 
							</div>
						</div>
						<div class="col-xxl-7 ps-xl-5  ps-xxl-4 ps-lg-0 ps-md-4 col-xl-7 col-lg-8 col-md-7 col-sm-7">
							<div class="input-field-group ">
								<label for="username">Ttile 1</label>
								<input class="w-100" type="text" name="username" id="username">
							</div>
							<div class="input-field-group ">
								<label for="username">Description 1</label>
								<textarea></textarea>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-xxl-5 col-xl-5 col-lg-4 col-md-5 col-sm-5">
							<div class="profile-img-holder mb-3">
								<figcaption>Image 2</figcaption>
								<div id="alfarada-img2-preview" class="image-preview">
									<label for="alfarada-img2-upload" id="alfarada-img2-label">EDIT IMAGE</label>
									<input type="file" name="image" id="alfarada-img2-upload" />
								</div> 
							</div>
						</div>
						<div class="col-xxl-7 ps-xxl-4 ps-xl-5 col-xl-7 col-lg-8 col-sm-7 col-md-7 ps-lg-0 ps-md-4">
							<div class="input-field-group ">
								<label for="username">Ttile 2</label>
								<input class="w-100" type="text" name="username" id="username">
							</div>
							<div class="input-field-group ">
								<label for="username">Description 2</label>
								<textarea></textarea>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="col-xxl-6 col-xl-6 col-12">
			<div>
				<h2 class="table-cap  mb-2">FAQ</h2>
				<a class="add-btn my-3 px-0" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-question">Add new question</a>
			</div>
			<div class=" table-responsive tenant-table">
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th>Question</th>
							<th>Answer</th>
							<th colspan="2"></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="p-2">
								<p class="text-start fs-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
							</td>
							<td class="p-2">
								<p class="text-start fs-13">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
								</p>
							</td>
							<td class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">Edit</td> 
							<td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
						</tr>
						<tr>
							<td class="p-2">
								<p class="text-start fs-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
							</td>
							<td class="p-2">
								<p class="text-start fs-13">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
								</p>
							</td>
							<td class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#edit-question">Edit</td>
							<td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
						</tr>
						<tr>
							<td class="p-2">
								<p class="text-start fs-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
							</td>
							<td class="p-2">
								<p class="text-start fs-13">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
								</p>
							</td>
							<td  class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#edit-question">Edit</td>
							<td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
						</tr>
						<tr>
							<td class="p-2">
								<p class="text-start fs-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
							</td>
							<td class="p-2">
								<p class="text-start fs-13">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
								</p>
							</td>
							<td  class="table-edit fw-bold" data-bs-toggle="modal" data-bs-target="#edit-question">Edit</td>
							<td  class=" fw-bold" data-bs-toggle="modal" data-bs-target="#remove-item">REMOVE</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
<!-- add question model start -->
<div class="modal fade" id="add-question"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog ">
    
    <div class="modal-content  bg-transparent border-0">
      <div class="modal-body">
        <div class="container-fluid px-0">
          <div class="scnd-type-modal-form-wrapper">
            <form>
              <h2 class="form-caption">add Question</h2>
              <button type="button" class="btn-close-modal float-end mt-0 me-0" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
              <!-- frst row -->
              <div class="row">
                <div class="col-12">
                  <div class="input-field-group">
                    <label >Question</label>
                    <textarea class="description"></textarea>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class=" col-12">
                  <div class="input-field-group">
                    <label >Answer</label>
                    <textarea class="description"></textarea>
                  </div>
                </div>
              </div>

              <!-- scnd row -->
              <div class="row">
                <div class="col-12">
                  <div class="btn-holder">
                    <a href="#">Publish</a>
                    <a href="#">Draft</a>
                  </div>
                </div>
              </div>
              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- add question model end -->
<!-- edit question model start -->
<div class="modal fade" id="edit-question"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog ">
    
    <div class="modal-content  bg-transparent border-0">
      <div class="modal-body">
        <div class="container-fluid px-0">
          <div class="scnd-type-modal-form-wrapper">
            <form>
              <h2 class="form-caption">Edit Question</h2>
              <button type="button" class="btn-close-modal float-end mt-0 me-0" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
              <!-- frst row -->
              <div class="row">
                <div class="col-12">
                  <div class="input-field-group">
                    <label >Question</label>
                    <textarea class="description"></textarea>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class=" col-12">
                  <div class="input-field-group">
                    <label >Answer</label>
                    <textarea class="description"></textarea>
                  </div>
                </div>
              </div>

              <!-- scnd row -->
              <div class="row">
                <div class="col-12">
                  <div class="btn-holder">
                    <a href="#">Publish</a>
                    <a href="#">Draft</a>
                  </div>
                </div>
              </div>
              
            </form>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>
</div>
<!-- edit question model end -->
@endsection
