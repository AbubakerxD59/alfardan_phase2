@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Hotels')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
	<h2 class="table-cap pb-2">Hotels</h2>
	<a class="add-btn my-3" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#addnewhotel">ADD NEW HOTEL</a>
	<div class=" table-responsive tenant-table">
		<table class="table  table-bordered">
			<thead>
				<tr>
					<th scope="col"><span>Hotel Name</span></th>
					<th scope="col"><span>Date</span></th>
					<th scope="col"><span>Location</span></th>
					<th scope="col"><span>Status</span></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><a href="{{route('admin.hotel_view')}}">Hotel 1</a></td>
					<td>11/12/2021</td>
					<td>AF1 Building</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold"  data-bs-toggle="modal" data-bs-target="#editUser">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Delete</a></td>
				</tr>
				<tr>
					<td><a href="hotel-view.html">Hotel 1</a></td>
					<td>11/12/2021</td>
					<td>AF1 Building</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#editUser">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Delete</a></td>
				</tr>
				<tr>
					<td><a href="hotel-view.html">Hotel 1</a></td>
					<td>11/12/2021</td>
					<td>AF1 Building</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold"  data-bs-toggle="modal" data-bs-target="#editUser">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Delete</a></td>
				</tr>
				<tr>
					<td><a href="hotel-view.html">Hotel 1</a></td>
					<td>11/12/2021</td>
					<td>AF1 Building</td>
					<td>Draft</td>
					<td class="cursor-pointer fw-bold"  data-bs-toggle="modal" data-bs-target="#editUser">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Delete</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add Hotel model start -->
<div class="modal fade" id="addnewhotel"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">

		<div class="modal-content">             
			<div class="modal-body profile-model">
				<div class="container-fluid px-0">
					<div class="row">
						<div class="col-12">
							<div class="body-wrapper">
								<h2 class="table-cap pb-2 text-capitalize mb-3 ms-2 mt-3 ">Add Hotel</h2>
								
								<form>
									<div class="row">
										<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4  ">
											<div class="add-family-form-wrapper ps-2 pe-3">
												<label>Hotel Name</label>
												<input  type="text" name="username">
												<label>Call Number</label>
												<input  type="text" name="username">
												<label>Booking Link</label>
												<input  type="text" name="username">
												<div class="location-indicator">
													<label>Location</label>
													<input class="pe-4" type="text" name="username">
													<i class="fa fa-map-marker-alt"></i>
												</div>
												<label>Description</label>
												<textarea class="description-text-small"></textarea>
											</div>
										</div>
										<div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8 ps-4 label-size">
											<div class="profile-img-holder add-event-img-holder  mb-3">
												<figcaption>Images</figcaption>
												<div id="add-hotel-img-preview-modal1"  class="image-preview">
													<label class="text-uppercase" for="add-hotel-img-upload-modal1" id="add-hotel-img-label-modal1">add image</label>
													<input type="file" name="image" id="add-hotel-img-upload-modal1" />
												</div>
												<div id="add-hotel-img-preview-modal2"  class="image-preview">
													<label class="text-uppercase" for="add-hotel-img-upload-modal2" id="add-hotel-img-label-modal2">add image</label>
													<input type="file" name="image" id="add-hotel-img-upload-modal2" />
												</div>
												<div id="add-hotel-img-preview-modal3"  class="image-preview">
													<label class="text-uppercase" for="add-hotel-img-upload-modal3" id="add-hotel-img-label-modal3">add image</label>
													<input type="file" name="image" id="add-hotel-img-upload-modal3" />
												</div>
											</div>
											<h2>Tenant</h2>
											<div class="profile-tenant-form">
												<div class="form-check form-check-inline">
													<input class="form-check-input" type="radio" id="inlineCheckbox1" name="tenantinput" value="option1">
													<label class="form-check-label" for="inlineCheckbox1">VIP</label>
												</div>

												<div class="form-check form-check-inline">
													<input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox2" value="option2">
													<label class="form-check-label" for="inlineCheckbox2">Regular</label>
												</div>

												<div class="form-check form-check-inline mb-2">
													<input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox3" value="option3">
													<label class="form-check-label" for="inlineCheckbox3">Non-Tenant</label>
												</div>

												<h2>Property</h2>
												<div class="property-input-wrapper">
													<div class="form-check form-check-inline">
														<input class="form-check-input" name="property" type="radio" id="Property1" value="option1">
														<label class="form-check-label" for="Property1">Property 1</label>
													</div>

													<div class="form-check form-check-inline">
														<input class="form-check-input" name="property" type="radio" id="Property2" value="option2">
														<label class="form-check-label" for="Property2">Property 2</label>
													</div>

													<div class="form-check form-check-inline mb-2">
														<input class="form-check-input" name="property" type="radio" id="Property3" value="option3">
														<label class="form-check-label" for="Property3">Property 3</label>
													</div>

													<div class="form-check form-check-inline">
														<input class="form-check-input" name="property" type="radio" id="Property4" value="option4">
														<label class="form-check-label" for="Property4">Property 4</label>
													</div>

													<div class="form-check form-check-inline">
														<input class="form-check-input" name="property" type="radio" id="Property5" value="option4">
														<label class="form-check-label" for="Property5">Property 5</label>
													</div>

													<div class="form-check form-check-inline mb-2">
														<input class="form-check-input" name="property" type="radio" id="Property6" value="option6">
														<label class="form-check-label" for="Property6">Property 6</label>
													</div>

													<div class="form-check form-check-inline mb-2">
														<input class="form-check-input" name="property" type="radio" id="Property7" value="option7">
														<label class="form-check-label" for="Property7">Property 7</label>
													</div>
												</div>
												<div class="form-btn-holder mb-3 text-end  me-xxl-0">
													<button class="form-btn">Publish</button>
													<button class="form-btn">Draft</button>
												</div>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add Hotel model end -->
 <!--Edit Hotel model start -->
 <div class="modal fade" id="editUser"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
 	<div class="modal-dialog modal-dialog-centered modal-lg">

 		<div class="modal-content">            
 			<div class="modal-body profile-model">
 				<div class="container-fluid px-0">
 					<div class="row">
 						<div class="col-12">
 							<div class="body-wrapper">
 								<h2 class="table-cap pb-2 text-capitalize mb-3 ms-2 mt-3 ">Edit Hotel</h2>
 							
 								<form>
 									<div class="row">
 										<div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4  ">
 											<div class="add-family-form-wrapper ps-2 pe-3">
 												<label>Hotel Name</label>
 												<input  type="text" name="username">
 												<label>Call Number</label>
 												<input  type="text" name="username">
 												<label>Booking Link</label>
 												<input  type="text" name="username">
 												<div class="location-indicator">
 													<label>Location</label>
 													<input class="pe-4" type="text" name="username">
 													<i class="fa fa-map-marker-alt"></i>
 												</div>
 												<label>Description</label>
 												<textarea class="description-text-small"></textarea>
 											</div>
 										</div>
 										<div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8 ps-4 label-size">
 											<div class="profile-img-holder add-event-img-holder  mb-3">
 												<figcaption>Images</figcaption>
 												<div id="edit-hotel-img-preview-modal1"  class="image-preview">
 													<label class="text-uppercase" for="edit-hotel-img-upload-modal1" id="edit-hotel-img-label-modal1">CHANGE IMAGE</label>
 													<input type="file" name="image" id="edit-hotel-img-upload-modal1" />
 												</div>
 												<div id="edit-hotel-img-preview-modal2"  class="image-preview">
 													<label class="text-uppercase" for="edit-hotel-img-upload-modal2" id="edit-hotel-img-label-modal2">CHANGE IMAGE</label>
 													<input type="file" name="image" id="edit-hotel-img-upload-modal2" />
 												</div>
 												<div id="edit-hotel-img-preview-modal3"  class="image-preview">
 													<label class="text-uppercase" for="edit-hotel-img-upload-modal3" id="edit-hotel-img-label-modal3">CHANGE IMAGE</label>
 													<input type="file" name="image" id="edit-hotel-img-upload-modal3" />
 												</div>
 											</div>
 											<h2>Tenant</h2>
 											<div class="profile-tenant-form">
 												<div class="form-check form-check-inline">
 													<input class="form-check-input" type="radio" id="inlineCheckbox1" name="tenantinput" value="option1">
 													<label class="form-check-label" for="inlineCheckbox1">VIP</label>
 												</div>

 												<div class="form-check form-check-inline">
 													<input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox2" value="option2">
 													<label class="form-check-label" for="inlineCheckbox2">Regular</label>
 												</div>

 												<div class="form-check form-check-inline mb-2">
 													<input class="form-check-input" name="tenantinput" type="radio" id="inlineCheckbox3" value="option3">
 													<label class="form-check-label" for="inlineCheckbox3">Non-Tenant</label>
 												</div>

 												<h2>Property</h2>
 												<div class="property-input-wrapper">
 													<div class="form-check form-check-inline">
 														<input class="form-check-input" name="property" type="radio" id="Property1" value="option1">
 														<label class="form-check-label" for="Property1">Property 1</label>
 													</div>

 													<div class="form-check form-check-inline">
 														<input class="form-check-input" name="property" type="radio" id="Property2" value="option2">
 														<label class="form-check-label" for="Property2">Property 2</label>
 													</div>

 													<div class="form-check form-check-inline mb-2">
 														<input class="form-check-input" name="property" type="radio" id="Property3" value="option3">
 														<label class="form-check-label" for="Property3">Property 3</label>
 													</div>

 													<div class="form-check form-check-inline">
 														<input class="form-check-input" name="property" type="radio" id="Property4" value="option4">
 														<label class="form-check-label" for="Property4">Property 4</label>
 													</div>

 													<div class="form-check form-check-inline">
 														<input class="form-check-input" name="property" type="radio" id="Property5" value="option4">
 														<label class="form-check-label" for="Property5">Property 5</label>
 													</div>

 													<div class="form-check form-check-inline mb-2">
 														<input class="form-check-input" name="property" type="radio" id="Property6" value="option6">
 														<label class="form-check-label" for="Property6">Property 6</label>
 													</div>

 													<div class="form-check form-check-inline mb-2">
 														<input class="form-check-input" name="property" type="radio" id="Property7" value="option7">
 														<label class="form-check-label" for="Property7">Property 7</label>
 													</div>
 												</div>
 												<div class="form-btn-holder mb-3 text-end  me-xxl-0">
 													<button class="form-btn">Apply</button>
 													<button class="form-btn">Draft</button>
 												</div>
 											</div>
 										</div>
 									</div>
 								</form>
 							</div>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>


 	</div>
 </div>
 <!-- model end -->
@endsection
