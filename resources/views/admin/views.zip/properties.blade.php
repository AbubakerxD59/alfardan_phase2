@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Properties')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<div class="table-cap-space-between">
		<h2 class="table-cap pb-2 float-start text-capitalize">Properties</h2>
		<a class="add-btn my-3 float-end" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-properties">Add new</a>
	</div>
	<div class=" table-responsive tenant-table clear-both ">
		<table class="table  table-bordered ">
			<thead>
				<tr>
					<th ><a  href="property-view.html" class="w-100 d-block"> Property Name</a></th>
					<th ><a  href="property-view.html" class="w-100 d-block">Location</a></th>
					<th ><a  href="property-view.html" class="w-100 d-block">No. Apartments</a></th>
					<th ><a  href="property-view.html" class="w-100 d-block">Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Property Name</td>
					<td>Location</td>
					<td>5</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-properties">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>Property Name</td>
					<td>Location</td>
					<td>6</td>
					<td>Draft</td>
					<td class="cursor-pointer fw-bold"  data-bs-toggle="modal" data-bs-target="#edit-properties">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>Property Name</td>
					<td>Location</td>
					<td>8</td>
					<td>Draft</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-properties">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>

				<tr>
					<td>Property Name</td>
					<td>Location</td>
					<td>5</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold"  data-bs-toggle="modal" data-bs-target="#edit-properties">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>

<!--Add properties form model start -->
<div class="modal fade" id="add-properties"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent" >
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper more-extra-width">
						<form>
							<h2 class="form-caption">Add Property</h2>
							
							<div class="row">
								<div class="col-xl-4 col-lg-4 col-md-5">
									<!-- frst row -->
									<div class="row">
										<div class="input-field-group">
											<label for="username">Property Name</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group location">
											<label for="username">Location</label>
											<input type="text"  class="pe-4" name="username" id="username">
											<i class="fas fa-map-marker-alt"></i>
										</div>

										<div class="input-field-group">
											<label for="username">3D View  Link</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Call Number</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Email</label>
											<input type="email" name="username" id="username">
										</div>
									</div>

								</div>
								<div class=" col-xl-8 col-lg-8 ps-xl-0 ps-lg-5 col-md-7">
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="profile-img-holder mb-3">
												<figcaption>Images</figcaption>
												<div id="add-properties-image-preview" class="image-preview">
													<label for="add-properties-image-upload" id="add-properties-image-label">ADD IMAGE</label>
													<input type="file" name="image" id="add-properties-image-upload" />
												</div> 
											</div>
										</div>
										<div class="col-xl-7">
											<div class="input-field-group">
												<label >Long Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>
									</div>

									<!-- 2nd row -->

									<div class="row">
										<div class="col-xl-5">
											<div class="input-field-group">
												<label >Short Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>

										<div class="col-xl-7 mt-auto">
											<div class="btn-holder">
												<a href="#">Publish</a>
												<a href="#">Draft</a>
											</div>
										</div>
									</div>

								</div>
							</div>

							<!-- sixth row-->


						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Add properties form model end -->
<!--edit properties form model start -->
<div class="modal fade" id="edit-properties"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog ">

		<div class="modal-content border-0 bg-transparent">
			<div class="modal-body">
				<div class="container-fluid px-0">
					<div class="scnd-type-modal-form-wrapper more-extra-width">
						<form>
							<h2 class="form-caption">Edit Property</h2>
							<button type="button" class="btn-close-modal mt-0 me-0 float-end" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
							<div class="row">
								<div class="col-xl-4 col-lg-4 col-md-5">
									<!-- frst row -->
									<div class="row">
										<div class="input-field-group">
											<label for="username">Property Name</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group location">
											<label for="username">Location</label>
											<input type="text" class="pe-4" name="username" id="username">
											<i class="fa fa-map-marker-alt"></i>
										</div>

										<div class="input-field-group">
											<label for="username">3D View  Link</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Call Number</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Email</label>
											<input type="email" name="username" id="username">
										</div>
									</div>

								</div>
								<div class=" col-xl-8 col-lg-8 ps-xl-0 ps-lg-5 col-md-7">
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="profile-img-holder mb-3">
												<figcaption>Images</figcaption>
												<div id="edit-properties-image-preview" class="image-preview">
													<label for="edit-properties-image-upload" id="edit-properties-image-label">EDIT IMAGE</label>
													<input type="file" name="image" id="edit-properties-image-upload" />
												</div> 
											</div>
										</div>
										<div class="col-xl-7">
											<div class="input-field-group">
												<label >Long Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>
									</div>

									<!-- 2nd row -->

									<div class="row">
										<div class="col-xl-5">
											<div class="input-field-group">
												<label >Short Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>

										<div class="col-xl-7 mt-auto">
											<div class="btn-holder">
												<a href="#">Publish</a>
												<a href="#">Draft</a>
											</div>
										</div>
									</div>

								</div>
							</div>

							<!-- sixth row-->


						</form>
					</div>
				</div>
			</div>
		</div>


	</div>
</div>
<!--Edit properties form model start -->

@endsection
