@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Family Member View')

@section('content')

<main class="user-info-wrapper col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">

	<h2 class="table-cap pb-1 mb-3 text-capitalize">family member<span class="user-info-id">AF894582</span></h2>

	<!-- First row -->
	<div class="row">
		<div class="col-xxl-3 col-xl-3">
			<figure class="user-profile-pic">
				<img src="{{asset('alfardan/assets/user-info-img.jpg')}}" alt="User Info Profile Pic">
			</figure>
		</div>
		<div class="col-xxl-9 col-xl-9 mt-auto ">
			<div class=" table-responsive tenant-table ">
				<caption>
					<h2 class="table-cap pb-0  text-capitalize float-start clear-both">user info</h2>
					<a href="#" class="contract-btn float-end mb-2">View Contract</a>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>User Name</span></th>
							<th scope="col"><span>Email</span></th>
							<th scope="col"><span>Password</span></th>
							<th scope="col"><span>Start Date</span></th>
							<th scope="col"><span>Phone Number</span></th> 
							<th scope="col"><span>Leasing Type</span></th>
							<th scope="col"><Span>Tenant Type</Span></th>
							<th scope="col"><span>Property</span></th>
							<th scope="col"><span>Apartment</span></th>
							<th scope="col"><span>No. Of Members</span></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><a href="#">User 1</a></td>
							<td>fsdfa@gmail.com</td>
							<td>******</td>
							<td>11/12/2021</td>
							<td>00996123456</td>                     
							<td>Corporate</td>
							<td>Regular</td>
							<td>Property 1</td>
							<td>Apartment A Apartment B</td>
							<td>10</td>
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- scnd row -->
	<div class="row">
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table unique-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Family members</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Name</span></th>
							<th scope="col"><span>Email</span></th>
							<th scope="col"><span>Phone Number</span></th> 
							<th colspan="2"></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Name</td>
							<td>fsdfa@gmail.com</td>
							<td>00996123456</td>
							<td><a href="#">edit</a></td>
							<td><a href="#">remove</a></td>
						</tr> 
						<tr>
							<td>Name</td>
							<td>fsdfa@gmail.com</td>
							<td>00996123456</td>
							<td><a href="#">edit</a></td>
							<td><a href="#">remove</a></td>

						</tr>       
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Lifestyle activities</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Lifestyle Type</span></th>
							<th scope="col"><span>Date Booked</span></th>
							<th scope="col"><span>No. of Reservation</span></th>
							<th scope="col"><span>Reservation Time</span></th>
							<th scope="col"><span>Rating</span></th> 
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Event</td>
							<td>11/12/2021</td>
							<td>3</td>
							<td>12:00 A.M</td>
							<td>5/5</td>                     
						</tr> 
						<tr>
							<td>Class</td>
							<td>11/12/2021</td>
							<td>2</td>
							<td>12:00 A.M</td>
							<td>5/4</td>                     
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- thrd row -->
	<div class="row">
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Hospitality Activities</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Hospitality Type</span></th>
							<th scope="col"><span>Date Booked</span></th>
							<th scope="col"><span>No. of Reservation</span></th>
							<th scope="col"><span>Reservation Time</span></th>
							<th scope="col"><span>Rating</span></th> 
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Event</td>
							<td>11/12/2021</td>
							<td>3</td>
							<td>12:00 A.M</td>
							<td>5/5</td>                     
						</tr> 
						<tr>
							<td>Class</td>
							<td>11/12/2021</td>
							<td>2</td>
							<td>12:00 A.M</td>
							<td>5/4</td>                     
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Maintenance Requests</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Maintenance Type</span></th>
							<th scope="col"><span>Date Booked</span></th>
							<th scope="col"><span>No. of Reservation</span></th>
							<th scope="col"><span>Reservation Time</span></th>
							<th scope="col"><span>Rating</span></th> 
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Event</td>
							<td>11/12/2021</td>
							<td>3</td>
							<td>12:00 A.M</td>
							<td>5/5</td>                     
						</tr> 
						<tr>
							<td>Class</td>
							<td>11/12/2021</td>
							<td>2</td>
							<td>12:00 A.M</td>
							<td>5/4</td>                     
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- frth row -->
	<div class="row">
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Concierge Requests</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Request</span></th>
							<th scope="col"><span>Type</span></th>
							<th scope="col"><span>Date</span></th>
							<th scope="col"><span>Status</span></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Pet Request</td>
							<td>Special</td>
							<td>11/12/2021</td>
							<td>Pending</td>
						</tr> 
						<tr>
							<td>Service</td>
							<td>Type</td>
							<td>11/12/2021</td>
							<td>Done</td>
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-xxl-6 col-xl-6">
			<div class=" table-responsive tenant-table">
				<caption>
					<h2 class="table-cap pb-0 mb-3 text-capitalize float-start clear-both">Sell Requests</h2>
				</caption>
				<table class="table  table-bordered">
					<thead>
						<tr>
							<th scope="col"><span>Product Name</span></th>
							<th scope="col"><span>Category</span></th>
							<th scope="col"><span>Phone Number</span></th>
							<th scope="col"><span>Status</span></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Name</td>
							<td>Electronics</td>
							<td>00996123456</td>
							<td>Pending</td>
						</tr>  
						<tr>
							<td>Name</td>
							<td>Electronics</td>
							<td>00996123456</td>
							<td>Sold</td>
						</tr>       
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- fifth row -->
	<section>
		<h2 class="review-heading">Review History</h2>
		<article class="article-wrapper">
			<span class="event-title">Event Name</span>
			<div class="rating-icon">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
			</div>
			<p class="description">
				Event description…Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
			</p>
			<time><span class="fst-italic">Added on</span> 12/20/2021</time>
		</article>

		<article class="article-wrapper">
			<span class="event-title">Event Name</span>
			<div class="rating-icon">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
			</div>
			<p class="description">
				Event description…Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
			</p>
			<time><span class="fst-italic">Added on</span> 12/20/2021</time>
		</article>

		<article class="article-wrapper">
			<span class="event-title">Event Name</span>
			<div class="rating-icon">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
			</div>
			<p class="description">
				Event description…Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
			</p>
			<time><span class="fst-italic">Added on</span> 12/20/2021</time>
		</article>
	</section>

</main>

@endsection
