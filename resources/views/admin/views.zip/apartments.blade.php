@extends('admin.layouts.layout')

@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@section('title','Apartments')

@section('content')

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-5 position">
	<h2 class="table-cap pb-1">Apartments</h2>
	<a class="add-btn my-3" href="#" type="button"  data-bs-toggle="modal" data-bs-target="#add-apartment">ADD NEW Apartments</a>
	<div class=" table-responsive tenant-table">
		<table class="table  table-bordered">
			<thead>
				<tr>
					<th ><a href="apartment-view.html" class="d-block w-100" >Apartment Name</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >Property Name</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >Location</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >No. Of Bedrooms</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >No. Of Bathrooms</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >Availability</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >Area</a></th>
					<th ><a href="apartment-view.html" class="d-block w-100" >Status</a></th>
					<th colspan="2"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Apartments</td>
					<td>Property</td>
					<td>Location</td>
					<td>5</td>
					<td>4</td>
					<td>Available</td>
					<td>123</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-apartment">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
				<tr>
					<td>Apartments</td>
					<td>Property</td>
					<td>Location</td>
					<td>3</td>
					<td>3</td>
					<td>Available</td>
					<td>123</td>
					<td>Published</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-apartment">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>

				</tr>
				<tr>
					<td>Apartments</td>
					<td>Property</td>
					<td>Location</td>
					<td>2</td>
					<td>3</td>
					<td>Occupied</td>
					<td>123</td>
					<td>Draft</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-apartment">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
				<tr>
					<td>Apartments</td>
					<td>Property</td>
					<td>Location</td>
					<td>1</td>
					<td>4</td>
					<td>Available</td>
					<td>123</td>
					<td>Draft</td>
					<td class="cursor-pointer fw-bold" data-bs-toggle="modal" data-bs-target="#edit-apartment">Edit</td>
					<td class="btn-bg2"><a  type="button" class="table-delete fw-bold">Remove</a></td>
				</tr>
			</tbody>
		</table>
	</div>

</main>
<!--Add apartment  model start -->
<div class="modal fade" id="add-apartment"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">

		<div class="modal-content border-0 bg-transparent">             
			<div class="modal-body profile-model">
				<div class="container-fluid">
					<div class="scnd-type-modal-form-wrapper more-extra-width">
						<form>
							<h2 class="form-caption">Add apartment</h2>
						
							<div class="row">
								<div class="col-xl-4 col-lg-4 col-md-12 apartment-select">
									<!-- frst row -->
									<div class="row">
										<div class="input-field-group">
											<label for="username">Apartment Name</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">No. of Bedrooms</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">No. of Bathrooms</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Area</label>
											<input type="text" name="username" id="username">
										</div>

									<label class="text-white" for="location">Property</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

										<div class="input-field-group location mt-3">
											<label for="username">Location</label>
											<input class=" pe-4"  type="text" name="username" id="username">
											<i class="fa fa-map-marker-alt"></i>
										</div>

										<div class="input-field-group mt-2">
											<label for="username">3D View  Link</label>
											<input type="text" name="username" id="username">
										</div>

									</div>

								</div>
								<div class=" col-xl-8 col-lg-8 ps-xl-0 ps-lg-5 col-md-12">
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="profile-img-holder mb-3">
												<figcaption>Images</figcaption>
												<div id="add-apartment-image-preview" class="image-preview">
													<label for="add-apartment-image-upload" id="add-apartment-image-label">ADD IMAGE </label>
													<input type="file" name="image" id="add-apartment-image-upload" />
												</div> 
											</div>
										</div>
										<div class="col-xl-7 col-lg-6">
											<div class="input-field-group">
												<label >Long Description</label>
												<textarea class="description mb-1"></textarea>
											</div>

											<div class="input-field-group">
												<label for="username">Availability</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<!-- 2nd row -->
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="input-field-group">
												<label >Short Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>
										<div class="col-xl-5 col-lg-6 ">
											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-xl-5">
											<div class="input-field-group">
												<label for="username">Call Number</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group py-2">
												<label for="username">Email</label>
												<input type="email" name="username" id="username">
											</div>
										</div>

										<div class="col-xl-7 mt-auto">
											<div class="btn-holder">
												<a href="#">Publish</a>
												<a href="#">Draft</a>
											</div>
										</div>
									</div>

								</div>
							</div>

							<!-- sixth row-->


						</form>
					</div>
				</div>
			</div>

		</div>


	</div>
</div>
<!--add apartmnet model end --> 
<!--edit apartment model start -->
<div class="modal fade" id="edit-apartment"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		
		<div class="modal-content border-0 bg-transparent"> 
			<div class="modal-body profile-model">
				<div class="container-fluid">
					<div class="scnd-type-modal-form-wrapper more-extra-width">
						<form>
							<h2 class="form-caption">edit apartment</h2>
							
							<div class="row">
								<div class="col-xl-4 col-lg-4 col-md-12 apartment-select">
									<!-- frst row -->
									<div class="row">
										<div class="input-field-group">
											<label for="username">Apartment Name</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">No. of Bedrooms</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">No. of Bathrooms</label>
											<input type="text" name="username" id="username">
										</div>

										<div class="input-field-group">
											<label for="username">Area</label>
											<input type="text" name="username" id="username">
										</div>

									
									<label class="text-white" for="location">Property</label>
									<div class="custom-select2 form-rounded my-2">
										<select id="location">
											<option value="0" selected></option>
											<option value="1">Property 1</option>
											<option value="2">Property 2</option>
											<option value="3">Property 3</option>
											<option value="4">Property 4</option>
											<option value="5">Property 5</option>
											<option value="6">Property 6</option>
											<option value="7">Property 7</option>

										</select>
									</div>

										<div class="input-field-group location mt-3">
											<label for="username">Location</label>
											<input class=" pe-4"  type="text" name="username" id="username">
											<i class="fa fa-map-marker-alt"></i>
										</div>

										<div class="input-field-group mt-1">
											<label for="username">3D View  Link</label>
											<input type="text" name="username" id="username">
										</div>

									</div>

								</div>
								<div class=" col-xl-8 col-lg-8 ps-xl-0 ps-lg-5 col-md-12">
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="profile-img-holder mb-3">
												<figcaption>Images</figcaption>
												<div id="edit-apartment-image-preview" class="image-preview">
													<label for="edit-apartment-image-upload" id="edit-apartment-image-label">EDIT IMAGE </label>
													<input type="file" name="image" id="edit-apartment-image-upload" />
												</div> 
											</div>
										</div>
										<div class="col-xl-7 col-lg-6">
											<div class="input-field-group">
												<label >Long Description</label>
												<textarea class="description mb-1"></textarea>
											</div>

											<div class="input-field-group">
												<label for="username">Availability</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>
									
									<!-- 2nd row -->
									<div class="row">
										<div class="col-xl-5 col-lg-6">
											<div class="input-field-group">
												<label >Short Description</label>
												<textarea class="description mb-1"></textarea>
											</div>
										</div>
										<div class="col-xl-5 col-lg-6 ">
											<div class="input-field-group">
												<label for="username">Status</label>
												<input type="text" name="username" id="username">
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-xl-5">
											<div class="input-field-group">
												<label for="username">Call Number</label>
												<input type="text" name="username" id="username">
											</div>

											<div class="input-field-group py-2">
												<label for="username">Email</label>
												<input type="email" name="username" id="username">
											</div>
										</div>

										<div class="col-xl-7 mt-auto">
											<div class="btn-holder">
												<a href="#">Publish</a>
												<a href="#">Draft</a>
											</div>
										</div>
									</div>

								</div>
							</div>
							
							<!-- sixth row-->
							
							
						</form>
					</div>
				</div>
			</div>
			
		</div>
		
		
	</div>
</div>
<!--edit apartment model end -->       
@endsection
